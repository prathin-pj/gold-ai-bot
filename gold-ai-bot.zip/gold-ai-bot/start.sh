#!/bin/bash
python auto_trade_loop.py